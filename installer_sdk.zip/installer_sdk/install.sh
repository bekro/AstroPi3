cp -d ./lib/* /usr/local/lib
cp -d ./lib/* /usr/lib/arm-linux-gnueabihf
cp -d ./lib/* /lib/arm-linux-gnueabihf

mkdir -p /usr/local/lib/qhy/firmware
cp -p ./firmware/* /usr/local/lib/qhy/firmware

cp ./udev/* /etc/udev/rules.d
cp ./udev/* /lib/udev/rules.d
cp ./udev/* /usr/local/udev

mkdir -p /usr/share/usb
cp ./fx3load/a3load.hex /usr/share/usb
cp ./fx3load/fxload /sbin
